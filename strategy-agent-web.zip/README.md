# Strategy Agent — Web Edition

An autonomous Business Strategy Agent that turns raw business data (CSV, JSON, or SQL)
into an executive strategy brief: key insights, data-backed hypotheses, a recommended
decision, a 90-day action plan, a risk matrix, and stakeholder charts.

This is a rebuild of an Android/AI Studio app as a plain web app: a small Node/Express
server serving a static frontend. All of the original data-ingestion and strategy-reasoning
logic runs client-side in the browser; the server's only job is to safely proxy calls to
the Gemini API (if you provide a key) so the key is never exposed in browser JavaScript.
Without a key, the app still works fully — it falls back to its built-in rule-based
strategy engine.

## Run locally

```bash
npm install
npm start
```

Then open http://localhost:8080

To enable Gemini-powered summary refinement, create a `.env` file (see `.env.example`)
or export the variable directly:

```bash
export GEMINI_API_KEY=your_key_here
npm start
```

## Deploy to Google Cloud Run

These steps assume you already have a Google Cloud project with billing enabled.

1. **Install and initialize gcloud** (skip if already done):
   ```bash
   gcloud init
   gcloud auth login
   ```

2. **Set your project:**
   ```bash
   gcloud config set project YOUR_PROJECT_ID
   ```

3. **Enable the required APIs:**
   ```bash
   gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com
   ```

4. **Deploy directly from source** (Cloud Build will build the Dockerfile automatically):
   ```bash
   gcloud run deploy strategy-agent \
     --source . \
     --region us-central1 \
     --allow-unauthenticated
   ```

   If you want Gemini enrichment enabled in production, add:
   ```bash
     --set-env-vars GEMINI_API_KEY=your_key_here
   ```

5. When the deploy finishes, gcloud prints a **Service URL** that looks like:
   ```
   https://strategy-agent-xxxxxxxxxx.us-central1.run.app
   ```
   That's the URL to submit.

6. **Verify it's live:**
   ```bash
   curl https://strategy-agent-xxxxxxxxxx.us-central1.run.app/healthz
   ```
   Should return `ok`.

7. Open the URL in a browser, run an analysis, and take your submission screenshot.

## Project structure

```
webapp/
├── Dockerfile
├── package.json
├── server/
│   └── server.js        # Express server + /api/enrich Gemini proxy
└── public/
    ├── index.html
    ├── css/styles.css
    └── js/
        ├── ingestion.js  # dataset parsing (CSV/JSON/SQL) + statistics
        ├── reasoning.js  # rule-based strategy report generation
        ├── presets.js    # sample business datasets
        ├── charts.js     # bespoke SVG chart rendering
        └── app.js        # UI wiring, save/export, local vault
```
