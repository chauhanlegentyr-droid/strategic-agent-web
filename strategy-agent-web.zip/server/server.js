const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8080;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Cloud Run health check
app.get('/healthz', (req, res) => res.status(200).send('ok'));

// Tells the frontend whether server-side Gemini enrichment is available,
// without ever exposing the key itself.
app.get('/api/status', (req, res) => {
  res.json({ geminiConfigured: Boolean(GEMINI_API_KEY) });
});

// Proxies the enrichment call to Gemini so the API key never reaches the browser.
app.post('/api/enrich', async (req, res) => {
  if (!GEMINI_API_KEY) {
    return res.json({ text: null, reason: 'not_configured' });
  }
  const { prompt } = req.body || {};
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Missing prompt' });
  }

  try {
    const response = await fetch(`${GEMINI_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.2 }
      })
    });

    if (!response.ok) {
      return res.json({ text: null, reason: 'upstream_error' });
    }

    const data = await response.json();
    const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
    res.json({ text: candidateText });
  } catch (err) {
    res.json({ text: null, reason: 'request_failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Strategy Agent listening on port ${PORT}`);
});
