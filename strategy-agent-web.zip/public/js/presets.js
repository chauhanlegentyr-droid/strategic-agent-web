const PRESETS = [
  {
    id: 'saas_churn',
    title: 'SaaS Retention & Churn Metrics',
    subtitle: '150 accounts: MRR, ticket latency, weekly logins, contract length, NPS, churn status',
    format: 'CSV',
    defaultGoal: 'Reduce 90-day logo churn by 25% and protect $450k ARR across Enterprise and Mid-Market tiers.',
    rawContent: `account_id,tier,mrr,weekly_active_days,support_tickets_30d,ticket_resolution_hours,nps_score,contract_months,churned
AC-1001,Enterprise,12500,4.8,2,4.5,9,24,0
AC-1002,Enterprise,8200,3.2,8,28.0,4,12,1
AC-1003,Mid-Market,3400,2.1,6,32.4,5,12,1
AC-1004,Mid-Market,4100,4.5,1,3.2,10,24,0
AC-1005,SMB,950,1.2,5,19.5,6,1,1
AC-1006,Enterprise,15000,4.9,3,5.0,9,36,0
AC-1007,Mid-Market,2800,1.8,9,44.2,3,12,1
AC-1008,SMB,1200,3.4,2,8.1,8,12,0
AC-1009,Enterprise,9800,2.4,7,36.8,4,12,1
AC-1010,Mid-Market,3900,4.2,1,2.9,9,24,0
AC-1011,SMB,800,1.0,4,22.0,,1,1
AC-1012,Enterprise,18000,5.0,2,3.8,10,36,0
AC-1013,Mid-Market,3100,2.6,5,18.4,6,12,0
AC-1014,SMB,1100,3.9,0,0.0,8,12,0
AC-1015,Enterprise,11200,3.1,8,39.0,3,12,1
AC-1016,Mid-Market,4600,4.7,2,6.1,9,24,0
AC-1017,SMB,750,1.5,6,27.5,4,1,1
AC-1018,Enterprise,14500,4.6,1,2.5,10,24,0
AC-1019,Mid-Market,3600,2.0,7,31.2,4,12,1
AC-1020,SMB,1300,4.1,1,4.0,9,12,0`
  },
  {
    id: 'inventory_opt',
    title: 'Retail & Supply Chain Inventory',
    subtitle: 'SKU velocity, lead times, stockout events, carrying cost, margin, supplier reliability',
    format: 'CSV',
    defaultGoal: 'Optimize inventory turnover from 3.1x to 4.8x to reduce carrying costs without increasing stockout risk.',
    rawContent: `sku_id,category,monthly_sales_units,unit_cost,selling_price,lead_time_days,holding_cost_pct,stockout_events_year,supplier_on_time_pct
SKU-501,Electronics,1200,45.0,89.99,14,0.18,1,0.96
SKU-502,Electronics,340,120.0,249.99,35,0.22,6,0.78
SKU-503,Apparel,2800,12.5,34.50,21,0.15,2,0.92
SKU-504,Apparel,850,28.0,65.00,45,0.25,8,0.72
SKU-505,HomeGoods,1600,18.0,42.00,12,0.14,0,0.98
SKU-506,Electronics,210,350.0,699.00,50,0.24,9,0.68
SKU-507,HomeGoods,950,32.0,75.00,28,0.19,3,0.85
SKU-508,Beauty,3400,6.5,22.00,10,0.12,1,0.95
SKU-509,Apparel,420,45.0,110.00,40,0.26,7,0.74
SKU-510,Beauty,1900,11.0,32.00,15,0.13,1,0.94
SKU-511,Electronics,1450,55.0,119.99,16,0.18,2,0.91
SKU-512,HomeGoods,620,65.0,149.00,38,0.23,5,0.80
SKU-513,Beauty,2600,8.0,26.00,12,0.12,0,0.97
SKU-514,Apparel,3100,14.0,38.00,18,0.16,2,0.89
SKU-515,Electronics,180,480.0,950.00,55,0.28,11,0.65`
  },
  {
    id: 'sales_expansion',
    title: 'B2B Sales Pipeline & Market Expansion',
    subtitle: 'JSON export of deals: industry, deal size, sales cycle days, CAC, win rate, ARR expansion',
    format: 'JSON',
    defaultGoal: 'Identify top 2 highest-margin market segments to double down on for 2026 expansion.',
    rawContent: `[
  {"segment": "Fintech", "avg_deal_size": 85000, "sales_cycle_days": 42, "cac": 14200, "win_rate_pct": 34.5, "net_retention_pct": 138, "acv_growth_potential": "High"},
  {"segment": "Healthcare", "avg_deal_size": 115000, "sales_cycle_days": 118, "cac": 38000, "win_rate_pct": 18.2, "net_retention_pct": 112, "acv_growth_potential": "Medium"},
  {"segment": "E-Commerce", "avg_deal_size": 42000, "sales_cycle_days": 28, "cac": 7800, "win_rate_pct": 41.0, "net_retention_pct": 126, "acv_growth_potential": "High"},
  {"segment": "Manufacturing", "avg_deal_size": 92000, "sales_cycle_days": 95, "cac": 29500, "win_rate_pct": 21.0, "net_retention_pct": 105, "acv_growth_potential": "Low"},
  {"segment": "EdTech", "avg_deal_size": 31000, "sales_cycle_days": 35, "cac": 9400, "win_rate_pct": 29.0, "net_retention_pct": 98, "acv_growth_potential": "Low"},
  {"segment": "Cybersecurity", "avg_deal_size": 98000, "sales_cycle_days": 48, "cac": 16500, "win_rate_pct": 36.8, "net_retention_pct": 144, "acv_growth_potential": "Very High"}
]`
  },
  {
    id: 'unit_economics',
    title: 'Subscription Unit Economics & CAC',
    subtitle: 'SQL table export: channel, blended CAC, LTV, payback months, 12m churn, ROAS',
    format: 'SQL',
    defaultGoal: 'Reallocate marketing budget to reduce payback period under 8 months while sustaining >30% YoY growth.',
    rawContent: `INSERT INTO marketing_channels (channel_name, monthly_spend, blended_cac, ltv, payback_months, annual_churn_pct, roas) VALUES
('Search SEM', 65000, 480, 2450, 6.2, 14.5, 3.8),
('Paid Social', 82000, 790, 1850, 11.4, 26.0, 1.9),
('Content & Organic SEO', 22000, 160, 3100, 3.1, 9.8, 6.4),
('Partner & Affiliates', 38000, 340, 2600, 4.8, 12.0, 4.5),
('Outbound SDR', 54000, 950, 4200, 9.6, 11.2, 2.7),
('Display & Video Ads', 31000, 890, 1400, 14.2, 34.5, 1.3);`
  }
];
