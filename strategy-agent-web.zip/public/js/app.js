(() => {
  const $ = (id) => document.getElementById(id);

  const goalInput = $('goalInput');
  const datasetInput = $('datasetInput');
  const datasetMeta = $('datasetMeta');
  const presetList = $('presetList');
  const analyzeBtn = $('analyzeBtn');
  const analyzeBtnLabel = $('analyzeBtnLabel');
  const progressTrack = $('progressTrack');
  const progressFill = $('progressFill');
  const progressLabel = $('progressLabel');
  const errorBanner = $('errorBanner');
  const emptyState = $('emptyState');
  const report = $('report');
  const fileUpload = $('fileUpload');
  const vaultToggle = $('vaultToggle');
  const vaultCount = $('vaultCount');
  const vaultDrawer = $('vaultDrawer');
  const vaultOverlay = $('vaultOverlay');
  const vaultClose = $('vaultClose');
  const vaultList = $('vaultList');
  const toast = $('toast');

  const VAULT_KEY = 'strategyAgent.vault.v1';
  let activePresetId = null;
  let geminiConfigured = false;

  // ---------- init ----------
  function init() {
    renderPresets();
    loadPreset(PRESETS[0]);
    refreshVaultCount();
    fetch('/api/status').then(r => r.json()).then(d => { geminiConfigured = !!d.geminiConfigured; }).catch(() => {});

    analyzeBtn.addEventListener('click', runAnalysis);
    datasetInput.addEventListener('input', () => {
      activePresetId = 'custom';
      renderPresets();
      updateDatasetMeta();
    });
    fileUpload.addEventListener('change', handleFileUpload);
    vaultToggle.addEventListener('click', openVault);
    vaultClose.addEventListener('click', closeVault);
    vaultOverlay.addEventListener('click', closeVault);
  }

  function showToast(msg) {
    toast.textContent = msg;
    toast.hidden = false;
    setTimeout(() => { toast.hidden = true; }, 2400);
  }

  // ---------- presets ----------
  function renderPresets() {
    presetList.innerHTML = '';
    PRESETS.forEach(p => {
      const btn = document.createElement('button');
      btn.className = 'preset-item' + (p.id === activePresetId ? ' active' : '');
      btn.innerHTML = `
        <div class="preset-item-title">${escapeHtml(p.title)}</div>
        <div class="preset-item-sub">${escapeHtml(p.subtitle)}</div>
        <span class="preset-item-format">${escapeHtml(p.format)}</span>
      `;
      btn.addEventListener('click', () => loadPreset(p));
      presetList.appendChild(btn);
    });
  }

  function loadPreset(preset) {
    activePresetId = preset.id;
    datasetInput.value = preset.rawContent;
    goalInput.value = preset.defaultGoal;
    renderPresets();
    updateDatasetMeta();
  }

  function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      datasetInput.value = String(reader.result || '');
      activePresetId = 'custom';
      renderPresets();
      updateDatasetMeta();
    };
    reader.readAsText(file);
  }

  function updateDatasetMeta() {
    const text = datasetInput.value.trim();
    if (!text) { datasetMeta.textContent = 'No dataset loaded.'; return; }
    const parsed = Ingestion.parse(text, 'preview');
    if (parsed.totalRows === 0) {
      datasetMeta.textContent = 'Could not detect rows — check formatting.';
      return;
    }
    datasetMeta.textContent = `${parsed.format} · ${parsed.totalRows} rows · ${parsed.totalColumns} columns · ${parsed.cleanlinessScore}% clean`;
  }

  // ---------- analysis ----------
  async function runAnalysis() {
    const goal = goalInput.value.trim();
    const text = datasetInput.value.trim();
    hideError();

    if (!text) { showError('Please provide or select a business dataset.'); return; }
    if (!goal) { showError('Please specify a business challenge or goal.'); return; }

    setAnalyzing(true);

    try {
      await step('1/4 — Ingesting schema & normalizing missing metrics...', 25);
      const datasetName = activePresetId && activePresetId !== 'custom'
        ? (PRESETS.find(p => p.id === activePresetId) || {}).title
        : 'Custom Ingested Business Dataset';
      const dataset = Ingestion.parse(text, datasetName || 'Custom Ingested Business Dataset');

      await step('2/4 — Computing correlations & detecting operational outliers...', 50);
      let baseline = Reasoning.generate(dataset, goal, text);

      await step('3/4 — Drafting hypotheses & strategic decision...', 75);
      if (geminiConfigured) {
        const refined = await tryEnrich(dataset, goal, text);
        if (refined) baseline = { ...baseline, executiveSummary: refined };
      }

      await step('4/4 — Compiling executive brief...', 100);
      await sleep(200);

      renderReport(baseline);
    } catch (err) {
      console.error(err);
      showError('Something went wrong while analyzing this dataset. Try a smaller sample or check the format.');
    } finally {
      setAnalyzing(false);
    }
  }

  async function tryEnrich(dataset, goal, rawText) {
    try {
      const summaryLines = Object.entries(dataset.columnSummaries)
        .map(([k, v]) => v.isNumeric ? `${k}: Mean=${(v.mean || 0).toFixed(1)}, Min=${v.min}, Max=${v.max}` : null)
        .filter(Boolean).join(' | ');
      const prompt = `You are an autonomous Business Strategy Agent. Transform this raw business dataset into a strategic executive decision.

Business Goal: "${goal}"
Dataset Schema: Headers = ${dataset.headers.join(', ')}
Total Rows: ${dataset.totalRows}, Numeric Columns: ${dataset.numericColumns.join(', ')}
Cleanliness Score: ${dataset.cleanlinessScore}%
Key Computed Statistics: ${summaryLines}

Raw Data Snippet:
${rawText.slice(0, 800)}

Write exactly 3 clear, professional sentences for an Executive Summary explaining the findings and the recommended decision. Return only those 3 sentences, nothing else.`;

      const res = await fetch('/api/enrich', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      if (!res.ok) return null;
      const data = await res.json();
      if (!data.text) return null;
      const lines = data.text.split('\n').map(l => l.trim()).filter(Boolean);
      const candidates = lines.filter(l => l.length > 50 && !l.startsWith('#') && !l.startsWith('-') && !l.startsWith('*'));
      return candidates.length ? candidates.join(' ') : data.text.trim();
    } catch (e) {
      return null;
    }
  }

  function step(label, pct) {
    progressLabel.textContent = label;
    progressFill.style.width = pct + '%';
    return sleep(380);
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function setAnalyzing(isOn) {
    analyzeBtn.disabled = isOn;
    analyzeBtnLabel.textContent = isOn ? 'Analyzing…' : 'Run strategic analysis';
    progressTrack.hidden = !isOn;
    if (!isOn) { progressFill.style.width = '0%'; progressLabel.textContent = ''; }
  }

  function showError(msg) { errorBanner.textContent = msg; errorBanner.hidden = false; }
  function hideError() { errorBanner.hidden = true; }

  // ---------- rendering ----------
  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function renderReport(rep) {
    emptyState.hidden = true;
    report.hidden = false;

    const aiTag = geminiConfigured ? '<span class="ai-tag">Gemini-enriched</span>' : '';

    report.innerHTML = `
      <div class="memo-header">
        <div class="memo-eyebrow">
          <span>Executive Strategy Brief</span>
          <span>${new Date(rep.timestamp).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</span>
        </div>
        <div class="memo-title">${escapeHtml(rep.businessGoal)}</div>
        <div class="memo-goal">Source: ${escapeHtml(rep.datasetName)} · ${escapeHtml(rep.datasetFormat)} · ${rep.cleanlinessScore}% data cleanliness${aiTag}</div>
        <div class="memo-seal">Strategy<br/>Agent<br/>Brief</div>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Executive summary</div>
        <p class="memo-summary">${escapeHtml(rep.executiveSummary)}</p>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Key insights</div>
        <ul class="insight-list">
          ${rep.keyInsights.map((ins, i) => `<li><span class="insight-marker">${String(i + 1).padStart(2, '0')}</span><span>${escapeHtml(ins)}</span></li>`).join('')}
        </ul>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Data-backed hypotheses</div>
        ${rep.hypotheses.map(h => `
          <div class="hyp-card ${h.isPrimaryRecommendation ? 'primary' : ''}">
            <div class="hyp-top">
              <div class="hyp-title">${escapeHtml(h.title)}</div>
              ${h.isPrimaryRecommendation ? '<span class="hyp-badge">Primary</span>' : ''}
            </div>
            <div class="hyp-rationale">${escapeHtml(h.rationale)}</div>
            <div class="hyp-outcome">→ <strong>${escapeHtml(h.predictedOutcome)}</strong></div>
            <div class="confidence-row">
              <div class="confidence-track"><div class="confidence-fill" style="width:${h.confidenceScore}%"></div></div>
              <div class="confidence-label">${h.confidenceScore}% confidence</div>
            </div>
            <div class="metric-chips">${h.supportingMetrics.map(m => `<span class="metric-chip">${escapeHtml(m)}</span>`).join('')}</div>
          </div>
        `).join('')}
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Strategic decision</div>
        <div class="decision-block">
          <div class="decision-text">${escapeHtml(rep.strategicDecision)}</div>
          <div class="impact-text">${escapeHtml(rep.expectedBusinessImpact)}</div>
        </div>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">90-day action plan</div>
        <table class="ledger">
          <thead><tr><th>Action step</th><th>Owner</th><th>Timeline</th><th>Expected outcome</th></tr></thead>
          <tbody>
            ${rep.actionPlan.map(a => `
              <tr>
                <td>${escapeHtml(a.actionStep)}</td>
                <td><span class="owner-tag">${escapeHtml(a.owner)}</span></td>
                <td>${escapeHtml(a.timeline)}</td>
                <td>${escapeHtml(a.expectedOutcome)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Risk matrix</div>
        <table class="ledger">
          <thead><tr><th>Risk</th><th>Probability</th><th>Impact</th><th>Mitigation</th></tr></thead>
          <tbody>
            ${rep.riskMatrix.map(r => `
              <tr>
                <td>${escapeHtml(r.risk)}</td>
                <td><span class="risk-badge ${r.probability}">${escapeHtml(r.probability)}</span></td>
                <td><span class="risk-badge ${r.impact}">${escapeHtml(r.impact)}</span></td>
                <td>${escapeHtml(r.mitigation)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Stakeholder visualizations</div>
        ${rep.stakeholderVisualizations.map(v => {
          const { svg, legend } = Charts.render(v);
          return `
            <div class="chart-block">
              <div class="chart-title">${escapeHtml(v.title)}</div>
              ${svg}
              ${legend.length ? `<div class="chart-legend">${legend.map(([label, cls]) => `<span class="chart-legend-item"><span class="legend-swatch ${cls}"></span>${escapeHtml(label)}</span>`).join('')}</div>` : ''}
            </div>
          `;
        }).join('')}
      </div>

      <div class="memo-section">
        <div class="memo-section-label">Data gaps &amp; assumptions</div>
        <ul class="gap-list">
          ${rep.dataGapsAndAssumptions.map(g => `<li>${escapeHtml(g)}</li>`).join('')}
        </ul>
      </div>

      <div class="memo-footer">
        <button class="footer-btn primary" id="saveBtn">Save to vault</button>
        <button class="footer-btn" id="exportBtn">Export as text</button>
      </div>
    `;

    $('saveBtn').addEventListener('click', () => saveToVault(rep));
    $('exportBtn').addEventListener('click', () => exportAsText(rep));

    window.__lastReport = rep;
    report.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function exportAsText(rep) {
    const lines = [];
    lines.push(`EXECUTIVE STRATEGY BRIEF: ${rep.businessGoal}`);
    lines.push(`Dataset: ${rep.datasetName} (${rep.datasetFormat}) — ${rep.cleanlinessScore}% clean`);
    lines.push('');
    lines.push('EXECUTIVE SUMMARY');
    lines.push(rep.executiveSummary);
    lines.push('');
    lines.push('KEY INSIGHTS');
    rep.keyInsights.forEach((i, idx) => lines.push(`${idx + 1}. ${i}`));
    lines.push('');
    lines.push('HYPOTHESES');
    rep.hypotheses.forEach(h => {
      lines.push(`- ${h.title} (${h.confidenceScore}% confidence)`);
      lines.push(`  Rationale: ${h.rationale}`);
      lines.push(`  Outcome: ${h.predictedOutcome}`);
    });
    lines.push('');
    lines.push('STRATEGIC DECISION');
    lines.push(rep.strategicDecision);
    lines.push(rep.expectedBusinessImpact);
    lines.push('');
    lines.push('ACTION PLAN');
    rep.actionPlan.forEach(a => lines.push(`- [${a.timeline}] ${a.actionStep} — Owner: ${a.owner} — Outcome: ${a.expectedOutcome}`));
    lines.push('');
    lines.push('RISK MATRIX');
    rep.riskMatrix.forEach(r => lines.push(`- ${r.risk} (Prob: ${r.probability}, Impact: ${r.impact}) — Mitigation: ${r.mitigation}`));
    lines.push('');
    lines.push('DATA GAPS & ASSUMPTIONS');
    rep.dataGapsAndAssumptions.forEach(g => lines.push(`- ${g}`));

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `strategy-brief-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ---------- vault (localStorage) ----------
  function getVault() {
    try { return JSON.parse(localStorage.getItem(VAULT_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function setVault(list) { localStorage.setItem(VAULT_KEY, JSON.stringify(list)); }

  function saveToVault(rep) {
    const list = getVault();
    list.unshift(rep);
    setVault(list.slice(0, 30));
    refreshVaultCount();
    showToast('Saved to vault.');
  }

  function refreshVaultCount() {
    vaultCount.textContent = getVault().length;
  }

  function openVault() {
    renderVaultList();
    vaultOverlay.hidden = false;
    vaultDrawer.hidden = false;
  }
  function closeVault() {
    vaultOverlay.hidden = true;
    vaultDrawer.hidden = true;
  }

  function renderVaultList() {
    const list = getVault();
    if (list.length === 0) {
      vaultList.innerHTML = '<div class="vault-empty">No saved briefs yet. Run an analysis and save it to keep it here.</div>';
      return;
    }
    vaultList.innerHTML = list.map((rep, idx) => `
      <div class="vault-item" data-idx="${idx}">
        <div class="vault-item-title">${escapeHtml(rep.businessGoal)}</div>
        <div class="vault-item-meta">
          <span>${escapeHtml(rep.datasetName)}</span>
          <span>${new Date(rep.timestamp).toLocaleDateString()}</span>
        </div>
        <button class="vault-item-delete" data-del="${idx}">Delete</button>
      </div>
    `).join('');

    vaultList.querySelectorAll('.vault-item').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.matches('[data-del]')) return;
        const idx = Number(el.dataset.idx);
        const rep = getVault()[idx];
        if (rep) { renderReport(rep); closeVault(); }
      });
    });
    vaultList.querySelectorAll('[data-del]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = Number(btn.dataset.del);
        const list = getVault();
        list.splice(idx, 1);
        setVault(list);
        refreshVaultCount();
        renderVaultList();
      });
    });
  }

  init();
})();
