// Bespoke SVG chart rendering — no external chart libraries, styled to match
// the app's ledger/terminal design system.

const Charts = (() => {
  const W = 560, H = 260, PAD = { l: 48, r: 20, t: 16, b: 34 };

  function svgEl(w, h) {
    return `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg" class="chart-svg">`;
  }

  function axisLine(x1, y1, x2, y2) {
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="chart-axis"/>`;
  }

  function textEl(x, y, str, cls, anchor = 'middle') {
    return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="${cls}">${escapeHtml(str)}</text>`;
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function forecastChart(viz) {
    const pts = viz.points; // [label, actual, projected]
    const innerW = W - PAD.l - PAD.r, innerH = H - PAD.t - PAD.b;
    const allVals = pts.flatMap(p => [p[1], p[2]]);
    const minV = Math.min(...allVals) * 0.92;
    const maxV = Math.max(...allVals) * 1.08;
    const xStep = innerW / (pts.length - 1 || 1);
    const yScale = v => PAD.t + innerH - ((v - minV) / (maxV - minV || 1)) * innerH;
    const xScale = i => PAD.l + i * xStep;

    let actualPath = '', projPath = '';
    pts.forEach((p, i) => {
      const x = xScale(i);
      actualPath += (i === 0 ? 'M' : 'L') + x + ',' + yScale(p[1]) + ' ';
      projPath += (i === 0 ? 'M' : 'L') + x + ',' + yScale(p[2]) + ' ';
    });

    let out = svgEl(W, H);
    // gridlines
    for (let g = 0; g <= 4; g++) {
      const y = PAD.t + (innerH / 4) * g;
      out += `<line x1="${PAD.l}" y1="${y}" x2="${W - PAD.r}" y2="${y}" class="chart-grid"/>`;
    }
    out += axisLine(PAD.l, PAD.t, PAD.l, H - PAD.b);
    out += axisLine(PAD.l, H - PAD.b, W - PAD.r, H - PAD.b);
    out += `<path d="${actualPath.trim()}" class="chart-line-baseline" fill="none"/>`;
    out += `<path d="${projPath.trim()}" class="chart-line-projected" fill="none"/>`;
    pts.forEach((p, i) => {
      const x = xScale(i);
      out += `<circle cx="${x}" cy="${yScale(p[1])}" r="2.5" class="chart-dot-baseline"/>`;
      out += `<circle cx="${x}" cy="${yScale(p[2])}" r="3" class="chart-dot-projected"/>`;
      out += textEl(x, H - PAD.b + 16, p[0], 'chart-tick');
    });
    out += textEl(10, PAD.t + 4, Math.round(maxV), 'chart-tick', 'start');
    out += textEl(10, H - PAD.b, Math.round(minV), 'chart-tick', 'start');
    out += '</svg>';
    return { svg: out, legend: [['Baseline / status quo', 'baseline'], ['Projected with strategy', 'projected']] };
  }

  function barChart(viz) {
    const pts = viz.points; // [label, value]
    const innerW = W - PAD.l - PAD.r, innerH = H - PAD.t - PAD.b;
    const maxV = Math.max(...pts.map(p => p[1])) * 1.15;
    const bw = innerW / pts.length * 0.62;
    const gap = innerW / pts.length;

    let out = svgEl(W, H);
    for (let g = 0; g <= 4; g++) {
      const y = PAD.t + (innerH / 4) * g;
      out += `<line x1="${PAD.l}" y1="${y}" x2="${W - PAD.r}" y2="${y}" class="chart-grid"/>`;
    }
    out += axisLine(PAD.l, PAD.t, PAD.l, H - PAD.b);
    out += axisLine(PAD.l, H - PAD.b, W - PAD.r, H - PAD.b);
    pts.forEach((p, i) => {
      const barH = (p[1] / maxV) * innerH;
      const x = PAD.l + i * gap + (gap - bw) / 2;
      const y = H - PAD.b - barH;
      out += `<rect x="${x}" y="${y}" width="${bw}" height="${barH}" rx="2" class="chart-bar"/>`;
      out += textEl(x + bw / 2, y - 6, p[1], 'chart-tick-value');
      out += textEl(x + bw / 2, H - PAD.b + 16, p[0], 'chart-tick-small');
    });
    out += '</svg>';
    return { svg: out, legend: [] };
  }

  function scatterChart(viz) {
    const pts = viz.points; // [label, x, y]
    const innerW = W - PAD.l - PAD.r, innerH = H - PAD.t - PAD.b;
    const maxX = Math.max(...pts.map(p => p[1])) * 1.15;
    const maxY = Math.max(...pts.map(p => p[2])) * 1.25;
    const xScale = v => PAD.l + (v / maxX) * innerW;
    const yScale = v => PAD.t + innerH - (v / maxY) * innerH;

    let out = svgEl(W, H);
    for (let g = 0; g <= 4; g++) {
      const y = PAD.t + (innerH / 4) * g;
      out += `<line x1="${PAD.l}" y1="${y}" x2="${W - PAD.r}" y2="${y}" class="chart-grid"/>`;
    }
    out += axisLine(PAD.l, PAD.t, PAD.l, H - PAD.b);
    out += axisLine(PAD.l, H - PAD.b, W - PAD.r, H - PAD.b);
    pts.forEach(p => {
      const x = xScale(p[1]), y = yScale(p[2]);
      out += `<circle cx="${x}" cy="${y}" r="5.5" class="chart-scatter-dot"/>`;
      out += textEl(x, y - 10, p[0], 'chart-tick-small');
    });
    out += '</svg>';
    return { svg: out, legend: [] };
  }

  function render(viz) {
    if (viz.type === 'forecast') return forecastChart(viz);
    if (viz.type === 'bar') return barChart(viz);
    return scatterChart(viz);
  }

  return { render };
})();
