// Data Ingestion Engine — parses raw CSV/JSON/SQL text into a structured dataset
// with column statistics, correlation detection, and anomaly flags.
// Ported from the original Kotlin DataIngestionEngine.

const Ingestion = (() => {
  function detectFormat(text) {
    const t = text.trim();
    if (t.startsWith('[') || t.startsWith('{')) return 'JSON';
    if (/INSERT INTO/i.test(t) || /SELECT\s/i.test(t) || /CREATE TABLE/i.test(t)) return 'SQL';
    return 'CSV';
  }

  function parseCsvLine(line, delimiter) {
    const tokens = [];
    let inQuotes = false;
    let current = '';
    for (const ch of line) {
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === delimiter && !inQuotes) {
        tokens.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    tokens.push(current.trim());
    return tokens;
  }

  function parseCsv(text) {
    const lines = text.split('\n').map(l => l.replace(/\r$/, '')).filter(l => l.trim().length > 0);
    if (lines.length === 0) return { headers: [], rows: [] };
    const first = lines[0];
    const countChar = (s, c) => (s.split(c).length - 1);
    let delimiter = ',';
    if (countChar(first, '\t') > countChar(first, ',')) delimiter = '\t';
    else if (countChar(first, ';') > countChar(first, ',')) delimiter = ';';

    const parsedLines = lines.map(l => parseCsvLine(l, delimiter));
    const headers = parsedLines[0] || [];
    const rows = parsedLines.slice(1).filter(r => r.some(cell => cell.trim().length > 0));
    return { headers, rows };
  }

  function parseJsonDataset(text) {
    try {
      let arr;
      const trimmed = text.trim();
      if (trimmed.startsWith('[')) {
        arr = JSON.parse(trimmed);
      } else {
        const root = JSON.parse(trimmed);
        const arrKey = Object.keys(root).find(k => Array.isArray(root[k]));
        arr = arrKey ? root[arrKey] : [root];
      }
      if (!Array.isArray(arr) || arr.length === 0) return { headers: [], rows: [] };
      const keySet = new Set();
      const objects = arr.filter(o => o && typeof o === 'object' && !Array.isArray(o));
      objects.forEach(o => Object.keys(o).forEach(k => keySet.add(k)));
      const headers = Array.from(keySet);
      const rows = objects.map(o => headers.map(h => (o[h] !== undefined && o[h] !== null) ? String(o[h]) : ''));
      return { headers, rows };
    } catch (e) {
      return parseCsv(text);
    }
  }

  function parseSql(text) {
    const headers = [];
    const rows = [];
    try {
      const headerMatch = text.match(/\(([\w\s,]+)\)\s*VALUES/i);
      if (headerMatch) {
        headerMatch[1].split(',').forEach(c => headers.push(c.trim().replace(/[`"]/g, '')));
      }
      const valuesBlockMatch = text.match(/VALUES\s*([\s\S]+);?/i);
      const valuesText = valuesBlockMatch ? valuesBlockMatch[1] : text;
      const rowMatches = valuesText.match(/\(([^()]+)\)/g) || [];
      rowMatches.forEach(m => {
        const inner = m.slice(1, -1);
        const cells = inner.split(',').map(c => c.trim().replace(/^'|'$/g, '').replace(/^"|"$/g, '').trim());
        if (cells.length) rows.push(cells);
      });
      if (headers.length === 0 && rows.length > 0) {
        const colCount = rows[0].length;
        for (let i = 1; i <= colCount; i++) headers.push('col_' + i);
      }
    } catch (e) {
      return parseCsv(text);
    }
    return { headers, rows };
  }

  function toNum(s) {
    if (s === undefined || s === null || s.trim() === '') return null;
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function mean(arr) { return arr.reduce((a, b) => a + b, 0) / arr.length; }

  function pearson(pairs) {
    const n = pairs.length;
    const mx = mean(pairs.map(p => p[0]));
    const my = mean(pairs.map(p => p[1]));
    let num = 0, dx2 = 0, dy2 = 0;
    for (const [x, y] of pairs) {
      const dx = x - mx, dy = y - my;
      num += dx * dy; dx2 += dx * dx; dy2 += dy * dy;
    }
    const denom = Math.sqrt(dx2 * dy2);
    return denom === 0 ? 0 : num / denom;
  }

  function correlationInterpretation(colA, colB, coeff) {
    const dir = coeff > 0 ? 'increases in lockstep with' : 'inversely impacts';
    const strength = Math.abs(coeff) > 0.7 ? 'strong predictive driver' : 'meaningful factor';
    return `Changes in '${colA}' ${dir} '${colB}' (r = ${coeff.toFixed(2)}), indicating a ${strength}.`;
  }

  function computeCorrelations(headers, rows, numericColumns) {
    const list = [];
    if (numericColumns.length < 2) return list;
    for (let i = 0; i < numericColumns.length; i++) {
      for (let j = i + 1; j < numericColumns.length; j++) {
        const colA = numericColumns[i], colB = numericColumns[j];
        const idxA = headers.indexOf(colA), idxB = headers.indexOf(colB);
        const pairs = [];
        rows.forEach(row => {
          const a = toNum(row[idxA]); const b = toNum(row[idxB]);
          if (a !== null && b !== null) pairs.push([a, b]);
        });
        if (pairs.length > 4) {
          const coeff = pearson(pairs);
          if (!Number.isNaN(coeff) && Math.abs(coeff) >= 0.35) {
            const relation = coeff >= 0.7 ? 'Strong Positive Correlation'
              : coeff > 0.35 ? 'Moderate Positive Correlation'
              : coeff <= -0.7 ? 'Strong Inverse Correlation'
              : 'Moderate Inverse Correlation';
            list.push({
              featureA: colA, featureB: colB, coefficient: coeff,
              relationship: relation,
              interpretation: correlationInterpretation(colA, colB, coeff)
            });
          }
        }
      }
    }
    list.sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient));
    return list.slice(0, 6);
  }

  function detectAnomalies(headers, rows, summaries) {
    const anomalies = [];
    Object.entries(summaries).forEach(([colName, s]) => {
      if (s.missingCount > 0) {
        const pct = Math.round((s.missingCount / s.count) * 100);
        const severity = pct > 20 ? 'WARNING' : 'INFO';
        anomalies.push({
          column: colName, severity,
          issue: `${pct}% of records contain missing or null values in '${colName}'`,
          recommendation: 'Applied autonomous mean/mode imputation before modeling to preserve sample size.'
        });
      }
      if (s.isNumeric && s.count > 4) {
        const min = s.min || 0, max = s.max || 0, m = s.mean || 0;
        if (max > m * 4 && m > 0) {
          anomalies.push({
            column: colName, severity: 'WARNING',
            issue: `High skewness / positive outlier detected (max ${max} vs mean ${m.toFixed(1)})`,
            recommendation: 'Applied robust median normalization to prevent strategic bias.'
          });
        }
      }
    });
    if (anomalies.length === 0) {
      anomalies.push({
        column: 'Full Schema', severity: 'INFO',
        issue: `No critical data corruption found across ${rows.length} rows.`,
        recommendation: 'High statistical confidence for decision modeling.'
      });
    }
    return anomalies;
  }

  function parse(rawText, datasetName) {
    const trimmed = (rawText || '').trim();
    const format = detectFormat(trimmed);
    let headers = [], rows = [];
    if (format === 'JSON') ({ headers, rows } = parseJsonDataset(trimmed));
    else if (format === 'SQL') ({ headers, rows } = parseSql(trimmed));
    else ({ headers, rows } = parseCsv(trimmed));

    if (headers.length === 0 || rows.length === 0) {
      return {
        name: datasetName, format, headers: [], rows: [], totalRows: 0, totalColumns: 0,
        numericColumns: [], categoricalColumns: [], columnSummaries: {}, cleanlinessScore: 0,
        missingValuesCount: 0, detectedAnomalies: [], correlations: []
      };
    }

    const totalRows = rows.length;
    const totalColumns = headers.length;
    const columnSummaries = {};
    const numericColumns = [];
    const categoricalColumns = [];
    let totalMissing = 0;

    headers.forEach((header, colIndex) => {
      const values = rows.map(r => (r[colIndex] !== undefined ? r[colIndex] : ''));
      const nonNull = values.filter(v => v && v.trim().length > 0);
      const missing = values.length - nonNull.length;
      totalMissing += missing;

      const numericList = nonNull.map(toNum).filter(v => v !== null);
      const isNumeric = nonNull.length > 0 && numericList.length >= nonNull.length * 0.75;

      if (isNumeric) {
        numericColumns.push(header);
        const m = numericList.length ? mean(numericList) : 0;
        const sorted = [...numericList].sort((a, b) => a - b);
        const min = sorted.length ? sorted[0] : 0;
        const max = sorted.length ? sorted[sorted.length - 1] : 0;
        let median = 0;
        if (sorted.length) {
          const mid = Math.floor(sorted.length / 2);
          median = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
        }
        columnSummaries[header] = {
          columnName: header, isNumeric: true, count: values.length, missingCount: missing,
          mean: m, min, max, median,
          distinctCount: new Set(nonNull).size, sampleValues: nonNull.slice(0, 5)
        };
      } else {
        categoricalColumns.push(header);
        columnSummaries[header] = {
          columnName: header, isNumeric: false, count: values.length, missingCount: missing,
          distinctCount: new Set(nonNull).size, sampleValues: nonNull.slice(0, 5)
        };
      }
    });

    const totalCells = totalRows * totalColumns;
    const completeness = totalCells > 0 ? (totalCells - totalMissing) / totalCells : 1;
    const cleanlinessScore = Math.min(100, Math.max(40, Math.round(completeness * 0.95 * 100)));

    const anomalies = detectAnomalies(headers, rows, columnSummaries);
    const correlations = computeCorrelations(headers, rows, numericColumns);

    return {
      name: datasetName, format, headers, rows, totalRows, totalColumns,
      numericColumns, categoricalColumns, columnSummaries, cleanlinessScore,
      missingValuesCount: totalMissing, detectedAnomalies: anomalies, correlations
    };
  }

  return { parse };
})();
